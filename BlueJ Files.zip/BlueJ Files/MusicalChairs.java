/*******************************************************
* Musical Chairs
* CS 1083 Group Project
* Group Members
* Hadi Akbar, Rudolph Stephen, Marvellous Akinola
* version@ 0.1
* ******************************************************/

import javafx.animation.*;
import javafx.application.Application;
import javafx.beans.binding.Bindings;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.scene.effect.DropShadow;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javafx.scene.Node;
import java.util.*;
import javafx.util.Pair;
import javafx.geometry.Pos;
import javafx.animation.FadeTransition;
import javafx.animation.ParallelTransition;
import javafx.animation.PauseTransition;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.util.Duration;
import java.util.concurrent.Flow;
import java.io.InputStream;

/**
 * Main application class for Musical Chairs
 * Handles game initialization, screens, and game logic
 */
public class MusicalChairs extends Application {
    // Game state and UI components
    private Stage primaryStage;
    private ImageView currentView;
    private StackPane root;
    private boolean isTransitioning = false;
    private MediaPlayer musicPlayer;
    
    // Resource paths
    private static final String APP_LOGO = "resources/images/logo.png";
    private static final String MUSIC_FILE = "resources/music/backgroundMusic.mp3";
    private static final String WINNER_MUSIC = "resources/music/winnerMusic.mp3";
    private static final String PLAYER_CHAIR_IMAGE = "resources/images/player_chair.png";
    private static final String ELIMINATED_CHAIR_IMAGE = "resources/images/eliminated_chair.png";
    private static final String WINNER_SCREEN = "resources/images/winnerScreen.png";

    // Music files for all rounds
    private static final String[] ROUND_MUSIC = {
        "resources/music/music1.mp3",
        "resources/music/music2.mp3",
        "resources/music/music3.mp3",
        "resources/music/music4.mp3",
        "resources/music/music5.mp3",
        "resources/music/music6.mp3",
        "resources/music/music7.mp3"
    };

    // UI Components
    private Button letsPlayBtn;
    private Button gotItBtn;
    private Button startGameBtn;
    private GridPane nameGrid;
    private int currentPlayerCount = 4;
    private StackPane errorPopup;
    private GridPane gameGridPane;
    private List<Label> playerLabels = new ArrayList<>();
    
    // Game configuration
    private int gridRows = 4;
    private int gridCols = 6;
    private Random random = new Random();
    private List<Animation> transitions = new ArrayList<>();
    private boolean gameStarted = false;
    
    // Game state variables
    private MediaPlayer roundMusicPlayer;
    private Timeline roundTimer;
    private int currentRound = 1;
    private static final int[] ELIMINATION_COUNTS = {4, 4, 4, 2};
    private List<String> activePlayers;
    private Timeline duelTimer;
    private Timeline safetyTimer; 
    
    // Grid configurations for different player counts
    private static final int[][] GRID_SIZES = {
        {4, 6},  // 16 players (4x6)
        {3, 5},  // 12 players (3x5)
        {3, 3},  // 8 players (3x3)
        {2, 2}   // 4 players (2x2)
    };

    /*******************************************************
     * Main entry point for JavaFX application
     * @param primaryStage The primary stage for this application
     *******************************************************/
    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;
        
        initializeBackgroundMusic();
        
        // Setup root container
        root = new StackPane();
        root.setStyle("-fx-background-color: #000000;");
        
        Scene scene = new Scene(root, 1100, 618);
        
        // Load screen images
        Image introImage = new Image(getClass().getResourceAsStream("/resources/images/introScreen.png"));
        Image instructionsImage = new Image(getClass().getResourceAsStream("/resources/images/instuctionsScreen.png"));

        
        ImageView introView = new ImageView(introImage);
        ImageView instructionsView = new ImageView(instructionsImage);
        
        // Configure image scaling
        introView.setPreserveRatio(true);
        introView.fitWidthProperty().bind(root.widthProperty());
        instructionsView.setPreserveRatio(true);
        instructionsView.fitWidthProperty().bind(root.widthProperty());
        
        // Set initial view
        currentView = introView;
        root.getChildren().add(currentView);
        
        // Create UI buttons
        letsPlayBtn = createInvisibleButton(182, 480, 100);
        gotItBtn = createInvisibleButton(250, 400, 100);
        
        // Create error popup
        createErrorPopup();
        
        // Add initial UI elements
        root.getChildren().addAll(letsPlayBtn, errorPopup);
        
        // Configure stage
        primaryStage.setTitle("Musical Chairs");
        setPureJavaFXIcons();

        // Add logo to window
        try {
            primaryStage.getIcons().add(new Image(getClass().getResourceAsStream("/" + APP_LOGO)));
        } catch (Exception e) {
            System.err.println("Error loading application logo: " + e.getMessage());
        }
        
        primaryStage.setScene(scene);
        primaryStage.setFullScreenExitHint(" Press ESC to toggle fullscreen");
        primaryStage.setFullScreen(true);
        
        // Cleanup on exit
        primaryStage.setOnCloseRequest(event -> {
            if (musicPlayer != null) musicPlayer.stop();
            if (roundMusicPlayer != null) roundMusicPlayer.stop();
            stopAllAnimations();
        });
        
        // Handle ESC key for fullscreen toggle
        scene.addEventHandler(KeyEvent.KEY_PRESSED, event -> {
            if (event.getCode() == KeyCode.ESCAPE && !isTransitioning) {
                isTransitioning = true;
                if (primaryStage.isFullScreen()) {
                    primaryStage.setFullScreen(false);
                    primaryStage.setWidth(1100);
                    primaryStage.setHeight(618);
                    primaryStage.centerOnScreen();
                } else {
                    primaryStage.setFullScreen(true);
                }
                PauseTransition pause = new PauseTransition(Duration.millis(500));
                pause.setOnFinished(e -> isTransitioning = false);
                pause.play();
            }
        });
        
        // Block ENTER and SPACE keys
        scene.addEventFilter(KeyEvent.KEY_PRESSED, event -> {
            if (event.getCode() == KeyCode.ENTER || event.getCode() == KeyCode.SPACE) {
                event.consume();
            }
        });
        
        // Button handlers
        letsPlayBtn.setOnAction(e -> {
            root.getChildren().remove(letsPlayBtn);
            fadeToImage(instructionsView, () -> {
                root.getChildren().add(gotItBtn);
            });
        });
        
        gotItBtn.setOnAction(e -> {
            transitionToPlayerSelection();
        });
        
        primaryStage.show();
    }

    /*******************************************************
     * Creates and configures the error popup dialog
     *******************************************************/
    private void createErrorPopup() {
        errorPopup = new StackPane();
        errorPopup.setAlignment(Pos.CENTER);
        errorPopup.setVisible(false);
        
        VBox popupContent = new VBox(20);
        popupContent.setAlignment(Pos.CENTER);
        popupContent.setPadding(new Insets(30));
        popupContent.setStyle("-fx-background-color: rgba(200, 50, 50, 0.9); "
                + "-fx-background-radius: 15; "
                + "-fx-border-color: white; "
                + "-fx-border-width: 2; "
                + "-fx-border-radius: 15;");
        
        Text errorText = new Text();
        errorText.setFont(Font.font("Arial", FontWeight.BOLD, 24));
        errorText.setFill(Color.WHITE);
        
        Button okButton = new Button("OK");
        okButton.setStyle("-fx-background-color: white; "
                + "-fx-text-fill: #c83232; "
                + "-fx-font-weight: bold; "
                + "-fx-background-radius: 10; "
                + "-fx-padding: 8 20;");
        okButton.setOnAction(e -> hideErrorPopup());
        
        popupContent.getChildren().addAll(errorText, okButton);
        errorPopup.getChildren().add(popupContent);
    }

    /*******************************************************
     * Displays error message in popup dialog
     * @param message The error message to display
     *******************************************************/
    private void showErrorPopup(String message) {
        Text errorText = (Text)((VBox)errorPopup.getChildren().get(0)).getChildren().get(0);
        errorText.setText(message);
        errorPopup.setVisible(true);
        
        FadeTransition fadeIn = new FadeTransition(Duration.millis(300), errorPopup);
        fadeIn.setFromValue(0);
        fadeIn.setToValue(1);
        fadeIn.play();
    }
    
    /*******************************************************
     * Loads and sets application icons of various sizes
     *******************************************************/
    private void setPureJavaFXIcons() {
        try {
            List<Image> icons = new ArrayList<>();
            
            // Try to load various sizes
            String[] sizes = {"16", "32", "64", "128", "256"};
            for (String size : sizes) {
                try {
                    String path = "logo_" + size + "x" + size + ".png";
                    InputStream stream = getClass().getResourceAsStream(path);
                    if (stream != null) {
                        icons.add(new Image(stream));
                    }
                } catch (Exception e) {
                    System.out.println("Couldn't load icon size " + size);
                }
            }
            
            // Fallback to default logo
            if (icons.isEmpty()) {
                Image defaultIcon = new Image(getClass().getResourceAsStream("/" + APP_LOGO));
                if (defaultIcon != null) {
                    icons.add(defaultIcon);
                }
            }
            
            // Set loaded icons
            if (!icons.isEmpty()) {
                primaryStage.getIcons().addAll(icons);
            } else {
                System.err.println("No application icons could be loaded");
            }
            
        } catch (Exception e) {
            System.err.println("Error loading application icons: " + e.getMessage());
        }
    }
    
    /*******************************************************
     * Hides the error popup with fade animation
     *******************************************************/
    private void hideErrorPopup() {
        FadeTransition fadeOut = new FadeTransition(Duration.millis(300), errorPopup);
        fadeOut.setFromValue(1);
        fadeOut.setToValue(0);
        fadeOut.setOnFinished(e -> errorPopup.setVisible(false));
        fadeOut.play();
    }

    /*******************************************************
     * Initializes and starts background music
     *******************************************************/
    private void initializeBackgroundMusic() {
        try {
            // Stop existing music
            if (musicPlayer != null) {
                musicPlayer.stop();
            }
            
            // Load and start new music
            Media sound = new Media(getClass().getResource(MUSIC_FILE).toURI().toString());
            musicPlayer = new MediaPlayer(sound);
            musicPlayer.setCycleCount(MediaPlayer.INDEFINITE);
            musicPlayer.setVolume(0.3);
            musicPlayer.play();
        } catch (Exception e) {
            System.err.println("Error loading background music: " + e.getMessage());
        }
    }

    /*******************************************************
     * Creates an invisible button for image-based UI
     * @param yPos Vertical position
     * @param width Button width
     * @param height Button height
     * @return Configured invisible button
     *******************************************************/
    private Button createInvisibleButton(double yPos, double width, double height) {
        Button btn = new Button();
        btn.setStyle("-fx-background-color: red; -fx-padding: 0;");
        btn.setOpacity(0);
        btn.setTranslateY(yPos);
        btn.setPrefSize(width, height);
        return btn;
    }

    /*******************************************************
     * Transitions between images with fade effect
     * @param newView The new ImageView to show
     * @param onComplete Callback when transition completes
     *******************************************************/
    private void fadeToImage(ImageView newView, Runnable onComplete) {
        FadeTransition fadeOut = new FadeTransition(Duration.millis(300), currentView);
        fadeOut.setFromValue(1.0);
        fadeOut.setToValue(0.0);
        
        FadeTransition fadeIn = new FadeTransition(Duration.millis(300), newView);
        fadeIn.setFromValue(0.0);
        fadeIn.setToValue(1.0);
        
        fadeOut.setOnFinished(e -> {
            root.getChildren().remove(currentView);
            currentView = newView;
            root.getChildren().add(currentView);
            fadeIn.play();
        });
        
        fadeIn.setOnFinished(e -> {
            if (onComplete != null) {
                onComplete.run();
            }
        });
        
        fadeOut.play();
    }

    /*******************************************************
     * Transitions to player selection screen
     *******************************************************/
    private void transitionToPlayerSelection() {
        StackPane selectionRoot = new StackPane();
        selectionRoot.setStyle("-fx-background-color: linear-gradient(to bottom right, #ff7a7a, #ffcc00);");

        Pane watermarkPane = new Pane();
        createMusicAndChairWatermarks(watermarkPane);

        VBox mainLayout = new VBox(20);
        mainLayout.setPadding(new Insets(40, 20, 40, 20));
        mainLayout.setAlignment(Pos.TOP_CENTER);
        mainLayout.setStyle("-fx-background-color: rgba(255,255,255,0.85); "
                + "-fx-background-radius: 0; "
                + "-fx-border-color: white; "
                + "-fx-border-width: 0; "
                + "-fx-border-radius: 0;");

        Text title = new Text("CHOOSE PLAYERS");
        title.setFont(Font.font("Comic Sans MS", FontWeight.EXTRA_BOLD, 36));
        title.setFill(Color.web("#6a3093"));
        title.setEffect(new DropShadow(10, Color.web("#b993d6")));

        GridPane countGrid = new GridPane();
        countGrid.setHgap(25);
        countGrid.setVgap(25);
        countGrid.setAlignment(Pos.CENTER);

        // Create player count buttons
        int[] playerCounts = {4, 8, 12, 16};
        for (int i = 0; i < playerCounts.length; i++) {
            Button btn = createVibrantCountButton(playerCounts[i]);
            countGrid.add(btn, i % 2, i / 2);
        }

        nameGrid = new GridPane();
        nameGrid.setHgap(20);
        nameGrid.setVgap(20);
        nameGrid.setAlignment(Pos.CENTER);
        updateNameFields(4);

        startGameBtn = new Button("START GAME");
        startGameBtn.setFont(Font.font("Impact", FontWeight.BOLD, 30));
        startGameBtn.setStyle("-fx-background-color: #8E54E9; "
                + "-fx-text-fill: white; "
                + "-fx-background-radius: 25; "
                + "-fx-padding: 15 60;");
        startGameBtn.setEffect(new DropShadow(15, Color.web("#8E54E9")));

        mainLayout.getChildren().addAll(title, countGrid, nameGrid, startGameBtn);
        selectionRoot.getChildren().addAll(watermarkPane, mainLayout);

        root.getChildren().clear();
        root.getChildren().addAll(selectionRoot, errorPopup);
        
        startGameBtn.setOnAction(e -> {
            if (validatePlayerNames()) {
                List<String> playerNames = getPlayerNames();
                // Check for duplicate names
                Set<String> nameSet = new HashSet<>(playerNames);
                if (nameSet.size() < playerNames.size()) {
                    showErrorPopup("All player names must be unique!");
                } else {
                    theGameScreen(playerNames);
                }
            }
        });
    }

    /*******************************************************
     * Initializes and displays the main game screen
     * @param nameList List of player names
     *******************************************************/
    private void theGameScreen(List<String> nameList) {
        stopAllAnimations();
        root.getChildren().clear();
        
        // Background setup
        ImageView background = new ImageView(new Image(getClass().getResourceAsStream("/resources/images/gamebackgroundfinal.png")));
        background.setPreserveRatio(true);
        background.fitWidthProperty().bind(root.widthProperty());
        background.fitHeightProperty().bind(root.heightProperty());
        
        StackPane gameContainer = new StackPane();
        gameGridPane = new GridPane();
        gameGridPane.setAlignment(Pos.CENTER);
        gameGridPane.setHgap(40);
        gameGridPane.setVgap(40);
        gameGridPane.setStyle("-fx-background-color: transparent;");
    
        // Set initial grid size based on player count
        updateGridSize(nameList.size());
        
        gameContainer.getChildren().addAll(background, gameGridPane);
        root.getChildren().add(gameContainer);
        
        // Initialize game state
        activePlayers = new ArrayList<>(nameList);
        playerLabels.clear();
        transitions.clear();
        currentRound = 1;
        
        // Create player labels
        for (int i = 0; i < nameList.size(); i++) {
            String name = nameList.get(i);
            Label playerLabel = new Label(name);
            playerLabel.setUserData(i); // Store original index
            playerLabel.setFont(Font.font("Arial", FontWeight.BOLD, 18));
            playerLabel.setTextFill(Color.WHITE);
            playerLabel.setStyle("-fx-background-color: rgba(0,0,0,0.3); -fx-padding: 5;");
            playerLabel.setAlignment(Pos.CENTER);
            playerLabel.setPrefSize(100, 100);
            playerLabels.add(playerLabel);
        }
        
        distributePlayersAndChairs();
        startRound();
    }
    
    /*******************************************************
     * Distributes players and chairs around the grid perimeter
     *******************************************************/
    private void distributePlayersAndChairs() {
        gameGridPane.getChildren().clear();
        
        int numPlayers = playerLabels.size();
        int totalEdgeCells = 2 * (gridCols + gridRows) - 4; // Perimeter cells
        
        for (int i = 0; i < numPlayers; i++) {
            int position = i % totalEdgeCells;
            int row, col;
            
            // Calculate perimeter position
            if (position < gridCols) {
                row = 0; col = position; // Top edge
            } else if (position < gridCols + gridRows - 1) {
                row = position - gridCols + 1; col = gridCols - 1; // Right edge
            } else if (position < 2 * gridCols + gridRows - 2) {
                row = gridRows - 1; col = (2 * gridCols + gridRows - 3) - position; // Bottom edge
            } else {
                row = totalEdgeCells - position; col = 0; // Left edge
            }
            
            // Add chair
            ImageView chair = new ImageView(new Image(getClass().getResourceAsStream("/" + PLAYER_CHAIR_IMAGE)));
            chair.setFitWidth(80);
            chair.setFitHeight(80);
            gameGridPane.add(chair, col, row);
            
            // Add player
            Label player = playerLabels.get(i);
            gameGridPane.add(player, col, row);
            player.toFront();
        }
    }
    
    /*******************************************************
     * Updates grid dimensions based on player count
     * @param playerCount Number of active players
     *******************************************************/
    private void updateGridSize(int playerCount) {
        // Determine grid size based on player count
        if (playerCount >= 16) {
            gridRows = 4; gridCols = 6;
        } else if (playerCount >= 12) {
            gridRows = 3; gridCols = 5; 
        } else if (playerCount >= 8) {
            gridRows = 3; gridCols = 3;
        } else {
            gridRows = 2; gridCols = 2;
        }
        
        // Clear and reset grid constraints
        gameGridPane.getChildren().clear();
        gameGridPane.getColumnConstraints().clear();
        gameGridPane.getRowConstraints().clear();
        
        // Set column constraints
        for (int i = 0; i < gridCols; i++) {
            gameGridPane.getColumnConstraints().add(new ColumnConstraints(100));
        }
        // Set row constraints
        for (int i = 0; i < gridRows; i++) {
            gameGridPane.getRowConstraints().add(new RowConstraints(100));
        }
    }
    
    /*******************************************************
     * Starts a new game round with music and movement
     *******************************************************/
    private void startRound() {
        // Stop background music
        if (musicPlayer != null) {
            musicPlayer.stop();
        }
        
        try {
            // Stop previous round music
            if (roundMusicPlayer != null) {
                roundMusicPlayer.stop();
            }
            
            // Randomly select music for this round
            String randomMusicFile = ROUND_MUSIC[random.nextInt(ROUND_MUSIC.length)];
            Media music = new Media(getClass().getResource(randomMusicFile).toURI().toString());
            roundMusicPlayer = new MediaPlayer(music);
            roundMusicPlayer.setCycleCount(MediaPlayer.INDEFINITE);
            roundMusicPlayer.setVolume(0.7);
            roundMusicPlayer.play();
            
            // Start animations
            startGameAnimation();
            
            // Set random round duration (5-15 seconds)
            double roundDuration = 5 + (random.nextDouble() * 10);
            roundTimer = new Timeline(
                new KeyFrame(Duration.seconds(roundDuration), event -> endRound())
            );
            roundTimer.play();
            
            // Safety timer (15 seconds max)
            safetyTimer = new Timeline(
                new KeyFrame(Duration.seconds(15), event -> {
                    if (gameStarted) endRound();
                })
            );
            safetyTimer.play();
            
        } catch (Exception e) {
            System.err.println("Error loading round music: " + e.getMessage());
            // Fallback without music
            startGameAnimation();
            new Timeline(new KeyFrame(Duration.seconds(5 + (random.nextDouble() * 10)), 
                event -> endRound())).play();
        }
    }
    
    /*******************************************************
     * Ends the current round and triggers eliminations
     *******************************************************/
    private void endRound() {
        // Stop music immediately
        if (roundMusicPlayer != null) {
            roundMusicPlayer.stop();
        }
        
        // Stop timers
        if (roundTimer != null) {
            roundTimer.stop();
        }
        if (safetyTimer != null) {
            safetyTimer.stop();
        }
        
        // Stop animations
        stopPlayerAnimations();
        
        // Calculate eliminations for current round
        int eliminations = currentRound <= ELIMINATION_COUNTS.length 
            ? ELIMINATION_COUNTS[currentRound-1] 
            : 1;
        eliminations = Math.min(eliminations, activePlayers.size() - 2);
        
        if (eliminations > 0) {
            eliminatePlayers(eliminations);
        }
    }
    
    /*******************************************************
     * Eliminates specified number of players
     * @param count Number of players to eliminate
     *******************************************************/
    private void eliminatePlayers(int count) {
        // Ensure we keep at least 2 players
        count = Math.min(count, activePlayers.size() - 2);
        if (count <= 0) {
            if (activePlayers.size() == 2) {
                startFinalDuel();
            }
            return;
        }
    
        // Create list of indices to eliminate
        List<Integer> indicesToEliminate = new ArrayList<>();
        for (int i = 0; i < playerLabels.size(); i++) {
            if (activePlayers.contains(playerLabels.get(i).getText())) {
                indicesToEliminate.add(i);
            }
        }
        Collections.shuffle(indicesToEliminate);
        indicesToEliminate = indicesToEliminate.subList(0, count);
    
        ParallelTransition eliminationAnim = new ParallelTransition();
        List<Pair<ImageView, Label>> eliminatedPairs = new ArrayList<>();
    
        // Process each elimination
        for (int index : indicesToEliminate) {
            Label label = playerLabels.get(index);
            Integer col = GridPane.getColumnIndex(label);
            Integer row = GridPane.getRowIndex(label);
            
            if (row != null && col != null) {
                // Create red chair for eliminated player
                ImageView redChair = new ImageView(new Image(getClass().getResourceAsStream("/" + ELIMINATED_CHAIR_IMAGE)));
                redChair.setFitWidth(80);
                redChair.setFitHeight(80);
                
                // Remove original chair
                gameGridPane.getChildren().removeIf(node -> 
                    node instanceof ImageView && 
                    GridPane.getColumnIndex(node) == col && 
                    GridPane.getRowIndex(node) == row);
                
                // Add red chair
                gameGridPane.add(redChair, col, row);
                redChair.toBack();
                
                // Fade player
                FadeTransition fade = new FadeTransition(Duration.seconds(1), label);
                fade.setFromValue(1.0);
                fade.setToValue(0.7);
                eliminationAnim.getChildren().add(fade);
                
                eliminatedPairs.add(new Pair<>(redChair, label));
                
                // Remove from active players
                activePlayers.removeIf(name -> name.equals(label.getText()));
            }
        }
    
        eliminationAnim.setOnFinished(e -> {
            // Remove eliminated players
            playerLabels.removeIf(label -> {
                for (Pair<ImageView, Label> pair : eliminatedPairs) {
                    if (pair.getValue() == label) {
                        return true;
                    }
                }
                return false;
            });
            
            // Determine next phase
            if (activePlayers.size() > 4) {
                currentRound++;
                PauseTransition pause = new PauseTransition(Duration.seconds(3));
                pause.setOnFinished(event -> {
                    // Clean up red chairs
                    eliminatedPairs.forEach(pair -> gameGridPane.getChildren().remove(pair.getKey()));
                    
                    // Reset grid
                    updateGridSize(activePlayers.size());
                    distributePlayersAndChairs();
                    startRound();
                });
                pause.play();
            }
            else if (activePlayers.size() == 4) {
                currentRound++;
                PauseTransition pause = new PauseTransition(Duration.seconds(3));
                pause.setOnFinished(event -> {
                    eliminatedPairs.forEach(pair -> gameGridPane.getChildren().remove(pair.getKey()));
                    startFinalRound();
                });
                pause.play();
            }
            else if (activePlayers.size() == 2) {
                PauseTransition pause = new PauseTransition(Duration.seconds(3));
                pause.setOnFinished(event -> {
                    eliminatedPairs.forEach(pair -> gameGridPane.getChildren().remove(pair.getKey()));
                    startFinalDuel();
                });
                pause.play();
            }
        });
    
        eliminationAnim.play();
    }

    /*******************************************************
     * Starts the final round with 4 players
     *******************************************************/
    private void startFinalRound() {
        stopPlayerAnimations();
        updateGridSize(4); // Force 2x2 grid
        
        gameGridPane.getChildren().clear();
        
        // Create 2x2 grid
        for (int i = 0; i < playerLabels.size(); i++) {
            int row = i < 2 ? 0 : 1;
            int col = i % 2;
            
            ImageView chair = new ImageView(new Image(getClass().getResourceAsStream("/" + PLAYER_CHAIR_IMAGE)));
            chair.setFitWidth(80);
            chair.setFitHeight(80);
            gameGridPane.add(chair, col, row);
            
            Label player = playerLabels.get(i);
            gameGridPane.add(player, col, row);
            player.toFront();
        }
        
        startRound();
    }
    
    /*******************************************************
     * Starts the final duel between last 2 players
     *******************************************************/
    private void startFinalDuel() {
        // Stop all music
        if (musicPlayer != null) musicPlayer.stop();
        if (roundMusicPlayer != null) roundMusicPlayer.stop();
        
        try {
            // Load duel music
            String duelMusicFile = ROUND_MUSIC[random.nextInt(ROUND_MUSIC.length)];
            Media duelMusic = new Media(getClass().getResource(duelMusicFile).toURI().toString());
            roundMusicPlayer = new MediaPlayer(duelMusic);
            roundMusicPlayer.setCycleCount(MediaPlayer.INDEFINITE);
            roundMusicPlayer.setVolume(0.7);
            roundMusicPlayer.play();
        } catch (Exception e) {
            System.err.println("Error loading duel music: " + e.getMessage());
        }
        
        // Setup 2x2 grid
        gridRows = 2;
        gridCols = 2;
        gameGridPane.getChildren().clear();
        
        // Add chairs
        ImageView chair1 = new ImageView(new Image(getClass().getResourceAsStream("/" + PLAYER_CHAIR_IMAGE)));
        chair1.setFitWidth(100);
        chair1.setFitHeight(100);
        gameGridPane.add(chair1, 0, 0);
        
        ImageView chair2 = new ImageView(new Image(getClass().getResourceAsStream("/" + PLAYER_CHAIR_IMAGE)));
        chair2.setFitWidth(100);
        chair2.setFitHeight(100);
        gameGridPane.add(chair2, 1, 1);
        
        // Get final players
        List<Label> finalPlayers = new ArrayList<>();
        for (Label label : playerLabels) {
            if (activePlayers.contains(label.getText())) {
                finalPlayers.add(label);
            }
        }
        
        // Sort by original index
        finalPlayers.sort(Comparator.comparingInt(a -> (int)a.getUserData()));
        
        // Position players
        if (finalPlayers.size() >= 1) {
            gameGridPane.add(finalPlayers.get(0), 0, 0);
        }
        if (finalPlayers.size() >= 2) {
            gameGridPane.add(finalPlayers.get(1), 1, 1);
        }
        
        // Start rapid position swapping
        duelTimer = new Timeline(
            new KeyFrame(Duration.seconds(0.3), e -> {
                for (Label player : finalPlayers) {
                    Integer col = GridPane.getColumnIndex(player);
                    Integer row = GridPane.getRowIndex(player);
                    if (col != null && row != null) {
                        GridPane.setColumnIndex(player, (col + 1) % 2);
                        GridPane.setRowIndex(player, (row + 1) % 2);
                    }
                }
            })
        );
        duelTimer.setCycleCount(Animation.INDEFINITE);
        duelTimer.play();
        
        // Random duel duration (5-15 seconds)
        double duelDuration = 5 + (random.nextDouble() * 10);
        new Timeline(new KeyFrame(Duration.seconds(duelDuration), e -> endDuel())).play();
    }
    
    /*******************************************************
     * Ends the final duel and determines winner
     *******************************************************/
    private void endDuel() {
        // Stop animations and music
        if (duelTimer != null) {
            duelTimer.stop();
        }
        if (roundMusicPlayer != null) {
            roundMusicPlayer.stop();
        }
    
        // Random winner selection
        String winner = activePlayers.get(random.nextInt(activePlayers.size()));
        String loser = activePlayers.stream()
                        .filter(name -> !name.equals(winner))
                        .findFirst()
                        .orElse("");
    
        // Mark loser's chair
        for (Node node : gameGridPane.getChildren()) {
            if (node instanceof ImageView) {
                ImageView chair = (ImageView) node;
                Integer col = GridPane.getColumnIndex(node);
                Integer row = GridPane.getRowIndex(node);
                
                // Check if chair has loser
                boolean isLoserChair = false;
                for (Node labelNode : gameGridPane.getChildren()) {
                    if (labelNode instanceof Label &&
                        GridPane.getColumnIndex(labelNode) == col &&
                        GridPane.getRowIndex(labelNode) == row) {
                        
                        if (((Label)labelNode).getText().equals(loser)) {
                            isLoserChair = true;
                        }
                    }
                }
                
                // Change to red chair if loser
                if (isLoserChair) {
                    chair.setImage(new Image(getClass().getResourceAsStream("/" + ELIMINATED_CHAIR_IMAGE)));
                    
                    // Fade losing player
                    for (Node labelNode : gameGridPane.getChildren()) {
                        if (labelNode instanceof Label &&
                            GridPane.getColumnIndex(labelNode) == col &&
                            GridPane.getRowIndex(labelNode) == row) {
                            
                            FadeTransition fade = new FadeTransition(Duration.seconds(1), labelNode);
                            fade.setFromValue(1.0);
                            fade.setToValue(0.5);
                            fade.play();
                        }
                    }
                }
            }
        }
        
        // Show winner after delay
        PauseTransition delay = new PauseTransition(Duration.seconds(2));
        delay.setOnFinished(e -> showWinner(winner));
        delay.play();
    }
    
    /*******************************************************
     * Displays winner screen with celebration
     * @param winner Name of the winning player
     *******************************************************/
    private void showWinner(String winner) {
        // Stop all music
        if (musicPlayer != null) musicPlayer.stop();
        if (roundMusicPlayer != null) roundMusicPlayer.stop();
        
        try {
            // Play winner music
            Media winnerMedia = new Media(getClass().getResource(WINNER_MUSIC).toURI().toString());
            MediaPlayer winnerPlayer = new MediaPlayer(winnerMedia);
            winnerPlayer.setCycleCount(1);
            winnerPlayer.setVolume(0.7);
            winnerPlayer.play();
            
            this.roundMusicPlayer = winnerPlayer;
        } catch (Exception e) {
            System.err.println("Error loading winner music: " + e.getMessage());
        }
    
        // Clear game grid
        gameGridPane.getChildren().clear();
        
        // Load winner screen
        ImageView winnerBackground = new ImageView(new Image(getClass().getResourceAsStream("/" + WINNER_SCREEN)));
        winnerBackground.setPreserveRatio(true);
        winnerBackground.fitWidthProperty().bind(root.widthProperty());
        winnerBackground.fitHeightProperty().bind(root.heightProperty());
        
        // Create overlay
        StackPane winnerContainer = new StackPane();
        winnerContainer.getChildren().add(winnerBackground);
        
        // Winner announcement
        VBox centerBox = new VBox(10);
        centerBox.setAlignment(Pos.CENTER);
        
        Text winnerText = new Text(winner.toUpperCase());
        winnerText.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 54));
        winnerText.setFill(Color.web("#FFD700"));
        winnerText.setStyle(
            "-fx-stroke: white;" +
            "-fx-stroke-width: 1.5;" +
            "-fx-stroke-type: outside;" +
            "-fx-letter-spacing: 2px;");
        winnerText.setEffect(new DropShadow(10, Color.BLACK));
        
        centerBox.getChildren().add(winnerText);
        winnerContainer.getChildren().add(centerBox);
        
        // Action buttons
        HBox buttonBox = new HBox(20);
        buttonBox.setAlignment(Pos.BOTTOM_RIGHT);
        buttonBox.setPadding(new Insets(0, 20, 20, 0));
        
        Button playAgainBtn = new Button("Play Again");
        playAgainBtn.setStyle("-fx-background-color: #8E54E9; "
                + "-fx-text-fill: white; "
                + "-fx-font-size: 24px; "
                + "-fx-padding: 10 30; "
                + "-fx-background-radius: 10;");
        playAgainBtn.setOnAction(e -> resetGame());
        
        Button exitBtn = new Button("Exit Game");
        exitBtn.setStyle("-fx-background-color: #c83232; "
                + "-fx-text-fill: white; "
                + "-fx-font-size: 24px; "
                + "-fx-padding: 10 30; "
                + "-fx-background-radius: 10;");
        exitBtn.setOnAction(e -> primaryStage.close());
        
        buttonBox.getChildren().addAll(playAgainBtn, exitBtn);
        winnerContainer.getChildren().add(buttonBox);
        
        // Position buttons
        StackPane.setAlignment(buttonBox, Pos.BOTTOM_RIGHT);
        
        root.getChildren().add(winnerContainer);
    }
   
    /*******************************************************
     * Resets game to initial state and returns to player selection
     *******************************************************/
    private void resetGame() {
        // Stop all music
        if (musicPlayer != null) {
            musicPlayer.stop();
        }
        if (roundMusicPlayer != null) {
            roundMusicPlayer.stop();
            roundMusicPlayer = null;
        }
        
        // Stop animations
        stopAllAnimations();
        
        // Clear game state
        playerLabels.clear();
        activePlayers.clear();
        transitions.clear();
        currentRound = 1;
        
        // Reset UI
        root.getChildren().clear();
        
        // Return to player selection
        transitionToPlayerSelection();
        
        // Restart background music
        initializeBackgroundMusic();
        
        // Reset flags
        gameStarted = false;
        isTransitioning = false;
    }
    
    /*******************************************************
     * Moves player labels clockwise around grid perimeter
     * @param label The player label to move
     *******************************************************/
    private void moveLabelClockwise(Label label) {
        if (!gameStarted) return;
    
        Integer currentRow = GridPane.getRowIndex(label);
        Integer currentCol = GridPane.getColumnIndex(label);
        
        if (currentRow == null || currentCol == null) return;
        
        Pair<Integer, Integer> nextPos = getNextClockwisePosition(currentRow, currentCol);
        
        if (nextPos != null) {
            gameGridPane.getChildren().remove(label);
            gameGridPane.add(label, nextPos.getValue(), nextPos.getKey());
            
            PauseTransition pause = new PauseTransition(Duration.millis(500));
            pause.setOnFinished(e -> moveLabelClockwise(label));
            pause.play();
            transitions.add(pause);
        }
    }   
    
    /*******************************************************
     * Calculates next clockwise position on grid perimeter
     * @param row Current row
     * @param col Current column
     * @return Pair of (row, col) for next position
     *******************************************************/
    private Pair<Integer, Integer> getNextClockwisePosition(int row, int col) {
        // Top edge (move right)
        if (row == 0 && col < gridCols - 1) return new Pair<>(row, col + 1);
        // Right edge (move down)
        if (col == gridCols - 1 && row < gridRows - 1) return new Pair<>(row + 1, col);
        // Bottom edge (move left)
        if (row == gridRows - 1 && col > 0) return new Pair<>(row, col - 1);
        // Left edge (move up)
        if (col == 0 && row > 0) return new Pair<>(row - 1, col);
        
        // Corners
        if (row == 0 && col == gridCols - 1) return new Pair<>(1, col); // Top-right → down
        if (row == gridRows - 1 && col == gridCols - 1) return new Pair<>(row, col - 1); // Bottom-right → left
        if (row == gridRows - 1 && col == 0) return new Pair<>(row - 1, col); // Bottom-left → up
        
        return null;
    }
       
    /*******************************************************
     * Starts animation for all player labels
     *******************************************************/
    private void startGameAnimation() {
        gameStarted = true;
        for (Label label : playerLabels) {
            moveLabelClockwise(label);
        }
    }
    
    /*******************************************************
     * Stops all player movement animations
     *******************************************************/
    private void stopPlayerAnimations() {
        gameStarted = false;
        for (Animation transition : transitions) {
            transition.stop();
        }
        transitions.clear();
    }
    
    /*******************************************************
     * Stops all game animations and timers
     *******************************************************/
    private void stopAllAnimations() {
        stopPlayerAnimations();
        if (roundTimer != null) roundTimer.stop();
        if (duelTimer != null) duelTimer.stop();
        if (safetyTimer != null) safetyTimer.stop();
    }
    
    /*******************************************************
     * Validates that all player names are entered
     * @return true if all names are valid, false otherwise
     *******************************************************/
    private boolean validatePlayerNames() {
        for (Node node : nameGrid.getChildren()) {
            if (node instanceof TextField) {
                TextField field = (TextField) node;
                if (field.getText().trim().isEmpty() || field.getText().trim().equals(field.getPromptText())) {
                    showErrorPopup("Please fill in all player names!");
                    return false;
                }
            }
        }
        return true;
    }

    /*******************************************************
     * Creates decorative watermarks for player selection screen
     * @param pane The pane to add watermarks to
     *******************************************************/
    private void createMusicAndChairWatermarks(Pane pane) {
        String[] emojis = {"🎶"};
        for (int i = 0; i < 30; i++) {
            Text emoji = new Text(emojis[i % emojis.length]);
            emoji.setFont(Font.font(40 + Math.random() * 30));
            emoji.setFill(getRandomEmojiColor());
            emoji.setLayoutX(Math.random() * 900 + 50);
            emoji.setLayoutY(Math.random() * 600 + 50);
            emoji.setRotate(Math.random() * 360);
            addShakingAnimation(emoji);
            pane.getChildren().add(emoji);
        }
    }

    /*******************************************************
     * Gets random color for emoji watermarks
     * @return Random Color object
     *******************************************************/
    private Color getRandomEmojiColor() {
        int rand = (int)(Math.random() * 4);
        switch (rand) {
            case 0: return Color.PURPLE;
            case 1: return Color.DARKBLUE;
            case 2: return Color.DARKGREEN;
            default: return Color.DARKRED;
        }
    }

    /*******************************************************
     * Adds shaking animation to emoji watermark
     * @param emoji The Text node to animate
     *******************************************************/
    private void addShakingAnimation(Text emoji) {
        TranslateTransition shake = new TranslateTransition(Duration.seconds(0.5 + Math.random() * 0.5), emoji);
        shake.setCycleCount(Animation.INDEFINITE);
        shake.setAutoReverse(true);
        shake.setByX(10);
        shake.play();
    }

    /*******************************************************
     * Creates vibrant player count selection button
     * @param count Number of players for this button
     * @return Configured button
     *******************************************************/
    private Button createVibrantCountButton(int count) {
        Button btn = new Button(count + " PLAYERS");
        btn.setFont(Font.font("Arial Rounded MT Bold", FontWeight.BOLD, 22));
        btn.setStyle("-fx-background-color: #6a3093; "
                + "-fx-text-fill: white; "
                + "-fx-background-radius: 20; "
                + "-fx-padding: 12 30; "
                + "-fx-border-color: white; "
                + "-fx-border-width: 2; "
                + "-fx-border-radius: 20;");
        btn.setEffect(new DropShadow(10, Color.web("#fbc2eb")));
        btn.setPrefWidth(220);

        btn.setOnAction(e -> updateNameFields(count));
        return btn;
    }

    /*******************************************************
     * Updates name input fields based on player count
     * @param count Number of players/fields to show
     *******************************************************/
    private void updateNameFields(int count) {
        currentPlayerCount = count;
        nameGrid.getChildren().clear();

        int columns = 4;
        for (int i = 1; i <= count; i++) {
            TextField field = new TextField();
            field.setPromptText("Player " + i);
            field.setFont(Font.font("Verdana", FontWeight.BOLD, 16));
            field.setStyle("-fx-background-color: white; "
                    + "-fx-background-radius: 10; "
                    + "-fx-border-color: #b993d6; "
                    + "-fx-border-width: 2; "
                    + "-fx-border-radius: 10; "
                    + "-fx-padding: 10 15; "
                    + "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.1), 5, 0, 0, 0);");
            field.setPrefHeight(45);
            
            field.addEventFilter(MouseEvent.MOUSE_CLICKED, event -> {
                if (field.getText().isEmpty()) {
                    field.setText(field.getPromptText());
                    field.selectAll();
                }
            });
            
            nameGrid.add(field, (i - 1) % columns, (i - 1) / columns);
        }
    }

    /*******************************************************
     * Gets list of entered player names
     * @return List of player names
     *******************************************************/
    private List<String> getPlayerNames() {
        List<String> playerNames = new ArrayList<>();
        for (Node node : nameGrid.getChildren()) {
            if (node instanceof TextField) {
                String name = ((TextField) node).getText().trim();
                if (!name.isEmpty()) {
                    playerNames.add(name);
                }
            }
        }
        return playerNames;
    }

    /*******************************************************
     * Main method to launch application
     * @param args Command line arguments
     *******************************************************/
    public static void main(String[] args) {
        launch(args);
    }
}